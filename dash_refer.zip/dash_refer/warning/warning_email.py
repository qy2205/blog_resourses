import os
os.chdir(os.getcwd() + "\\warning")
import pyemail
import datetime as dt

# --------------------- checking time --------------------- #
timenow = dt.datetime.now()
timenext = dt.datetime.now() + dt.timedelta(days = 1)
month1 = timenow.month
month2 = timenext.month

# --------------------- send email --------------------- #
if month1 != month2:
    sender = 'username@gmail.com'
    password = 'password'
    receiver = 'username@gmail.com'
    filename = '../db/rank.xlsx'
    title = "SPLs Warning From {0} to {1}".format(str(timenow)[:7], \
        str(timenext)[:7])
    msg = "Please see attached file of the rankings of SPLs based on the loan amount gap between the current month and last month"
    Gmailer = pyemail.Gmail_sender(sender, password, [receiver])
    Gmailer.send(title, msg, filename, filename2 = "SPLs_rank_{0}_to_{1}.xlsx".format(str(timenow)[:7], str(timenext)[:7]))


