# coding: utf-8
import os

import dash
import dash_table
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output
import plotly.graph_objs as go

import pandas as pd

from app import app
from apps import monitor
from apps import general_month
from apps import leaderboard
from apps import rank
from apps import comment
from apps import customer_value
from apps.template import Header


def base_layout():
    return html.Div([
                    dcc.Location(id='url', refresh=True),
                    html.Div(id='page-content')
                    ])
app.layout = base_layout

def make_dash_table(df):
    ''' Return a dash definition of an HTML table for a Pandas dataframe '''
    table = []
    for index, row in df.iterrows():
        html_row = []
        for i in range(len(row)):
            html_row.append(html.Td([row[i]]))
        table.append(html.Tr(html_row))
    return table

# page 2 Cohort Analysis
index_page = html.Div([
    html.Div([
        Header(),
    ], className="subpage")
], className="page")


# Update page
# # # # # # # # #
# detail in depth what the callback below is doing
# # # # # # # # #
@app.callback(Output('page-content', 'children'),
              [Input('url', 'pathname')])
def display_page(pathname):
    if pathname == '/apps':
        return monitor.layout
    # elif pathname == '/apps/overview':
    #     return overview.layout
    elif pathname == '/apps/general_month':
        return general_month.layout
    elif pathname == '/apps/monitor':
        return monitor.layout
    elif pathname == '/apps/rank':
        return rank.layout
    elif pathname == '/apps/leaderboard':
        return leaderboard.layout
    elif pathname == '/apps/comment':
        return comment.layout
    elif pathname == '/apps/scoring':
        return customer_value.layout
    else:
       return monitor.layout

# # # # # # # # #
# detail the way that external_css and external_js work and link to alternative method locally hosted
# # # # # # # # #
external_css = ["/static/normalize.min.css",
                "/static/skeleton.min.css",
                "//fonts.googleapis.com/css?family=Raleway:400,300,600",
                "/static/KQrXdb.css",
                "/static/font-awesome.min.css"]

for css in external_css:
    app.css.append_css({"external_url": css})

app.title = 'Roc monitor panel'

if __name__ == '__main__':
    app.run_server(debug = False)
    
