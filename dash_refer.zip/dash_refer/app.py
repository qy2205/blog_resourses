# coding: utf-8
# import flask
# import os
import dash
import dash_auth

external_css = ["/static/normalize.min.css",
                "/static/skeleton.min.css",
                "//fonts.googleapis.com/css?family=Raleway:400,300,600",
                "/static/KQrXdb.css",
                "/static/font-awesome.min.css"]

app = dash.Dash(__name__)
server = app.server

# # # # # # # # #
# detail the way that external_css and external_js work and link to alternative method locally hosted
# # # # # # # # #

for css in external_css:
    app.css.append_css({"external_url": css})

app.config.suppress_callback_exceptions = True
app.config.update({
    # as the proxy server will remove the prefix
    'routes_pathname_prefix': '/', 

    # the front-end will prefix this string to the requests
    # that are made to the proxy server
    'requests_pathname_prefix': '/lender_monitor/'
})

VALID_USERNAME_PASSWORD_PAIRS = {
    'roccapital': 'dsreport'
}

auth = dash_auth.BasicAuth(
    app,
    VALID_USERNAME_PASSWORD_PAIRS
)
