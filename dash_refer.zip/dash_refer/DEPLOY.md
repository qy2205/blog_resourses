### Deploy on AWS

1. In the local commend line tool, copy local file to AWS EC2
```
scp -i XXX.pem XXX.zip username@publicDNS:~/.
```

another way: windows pscp
```
pscp -i XXX.ppk XXX.zip ubuntu@publicDNS:/home/ubuntu/
```

2. log into the EC2 instance and install packages
```
sudo apt-get update
sudo apt-get install nginx
// uninstall nginx
// sudo apt-get purge nginx nginx-common
sudo rm /etc/nginx/sites-enabled/default
sudo vim /etc/nginx/sites-available/example.com
```

add the following to the example.com  
```
server {
	listen 80;

	location / {
		proxy_pass http://127.0.0.1:8000/;
	}
}
```

method 1: multiple applications
```
server {
        listen 80;

        location ^~ /name1 {
                proxy_pass http://127.0.0.1:8000/;
        }

        location ^~ /name2 {
                proxy_pass http://127.0.0.1:8050/;
        }

        location / {
                proxy_pass http://127.0.0.1:8000/;
        }

}
```
Bascially, we can go to publicDNS/name to get access to the website

```
sudo ln -s /etc/nginx/sites-available/example.com /etc/nginx/sites-enabled/example.com
sudo service nginx restart
```

Install python packages  
```
sudo apt-get install pip3
sudo apt-get install gunicorn3
pip3 install -r requirements.txt
```

3. run the web  
```
gunicorn3 XXX.py:app
```
run app on different port
```
gunicorn -w 4 -b 127.0.0.1:4000 run:app
```

### Updating

1. cd to the app directory
cd foldername

2. copy the file from loacal computer to EC2 instance
In local CMD:  
```
scp -i XXX.pem XXX.zip username@publicDNS:~/foldername
```

3. kill the flask server
```
ps aux | grep appname
kill processNum
```

notes: don't include '.' to the filename


### Bugs

For Flask-based Dash App, we need to change the route pathname to '/', or it will not find the dash dependency
```
app.config.update({
    # as the proxy server will remove the prefix
    'routes_pathname_prefix': '/', 

    # the front-end will prefix this string to the requests
    # that are made to the proxy server
    'requests_pathname_prefix': '/name/'
})
```

### Environment Setting
1. create a new environment 
```
virtualenv -p /usr/bin/python3 virtualenvironment/env_name
```
2. activate environment
```
cd virtualenvironment/env_name/bin
source activate
```
or
```
source virtualenvironment/project_1/bin/activate
```
3. deactivate environment
```
deactivate
```

### Static files 
```
location /static/ {
	try_files /rocinternal/datascience/$uri /loan_sizer$uri /rental-loan-pricer-master$uri;
}

alias /rocinternal/datascience/static/;
```
