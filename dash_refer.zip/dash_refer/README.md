# SPLs monitor dashboard

## File Structure
```
.
+-- roc_logo.jpg
+-- requirements.txt
+-- index.py
+-- app.py
+-- _warning
|   +-- pyemail.py
|   +-- warning_email.py
+-- _db
|   +-- comments.xlsx
|   +-- rank.xlsx
+-- _assets
|   +-- css.css
|   +-- favicon.icon
|   +-- font-awesome.min.css
|   +-- KQrXdb.css
|   +-- normalize.min.css
|   +-- skeleton.min.css
|   +-- roc_logo.jpg
+-- _apps
|   +-- __init__.py
|   +-- backend.py
|   +-- comment.py
|   +-- general_month.py
|   +-- monitor.py
|   +-- rank2.py
|   +-- rank.py
```

## Install Python  
**Step 1:** Download Anaconda3  
https://repo.anaconda.com/archive/Anaconda3-2019.07-Windows-x86_64.exe  

**Step 2:** Install Anaconda3  
*Note:* please add anaconda to my path environment variable  
![alt text](https://miro.medium.com/max/833/1*7a9zVyGP3iMXu9aB4e_Vhw.png "")

**Step 3:** create python environment with conda and activate environment  
1. open anaconda prompt  
2. create a new python environment  
`conda create --name dashreport python=3.6 anaconda`  
3. activate environment  
`conda activate dashreport`
4. cd to `dash_app_spls_monitor` folder  
5. install packages  
`pip install -r requirements.txt`  
6. run dashboard  
`python index.py`  
7. open chrome and go to http://127.0.0.1:8050/

## Python packages requirement
```
dash==1.1.1
gunicorn==19.9.0
plotly==4.1.0
dash_table==4.1.0
dash_auth==1.3.2
pandas==0.24.2
numpy==1.16.2
statsmodels==0.9.0
psycopg2==2.8.3
openpyxl==2.6.1
requests==2.22.0
```

## How to run it?
`python index.py`
