# coding: utf-8
import os

import math
import pandas as pd
import numpy as np

import dash_table
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output
import plotly.graph_objs as go
from app import app

import sys
sys.path.append(os.getcwd()+"/apps")
from backend import *
from template import Header

import warnings
warnings.filterwarnings("ignore")

# time, 1M, 3M, 6M, 1Y
timenow = dt.datetime.now().date()
# 1M
time1M = timenow - relativedelta(months = 1)
# 3M
time3M = timenow - relativedelta(months = 3)
# 6M
time6M = timenow - relativedelta(months = 6)
# 12M
time1Y = timenow - relativedelta(months = 12)

# ---------------------- functions ---------------------- #
# global variables: lender_name, status_data, timenow, time1M, time3M, time6M, time1Y
# global variables: lender_name, status_data, timenow, time1M, time3M, time6M, time1Y
def leaderboard_data(loan_type = None, submitted = True, funded = False, amount = True, 
                     times = False, delinquency = False, momentum = False, time_period = "1y"):
    '''
    Parameters
    ----------
    loan_type: {'fixflip', 'groudup', 'smallbalance', 'rental', None}
        default = None
        
        - 'fixflip' Fix and Flip (1-4)
        - 'groudup' Groundup (1-4)
        - 'smallbalance' Small Balance MF / Mixed Use (5+)
        - 'rental' Rental (1-4)
        - 'residential' Residential
        - None all types of loan
        
    submitted: bolean, default = True
        If true, date will includes all submitted loans
        
    funded: bolean, default = False
        If true, date will includes all funded loans

    amount: bolean, default = True
        If true, result will be the total amount of loans in a certain time period

    times: bolean, default = False
        If true, result will be the total number of loans in a certain time period

    delinquency: bolean, default = False
        If true, result will be the delinquency level in the whole period
        
    momentum: bolean, default = False
        If true, result will be the momentum level in a certain time period
        
    time_period: {'1m', '3m', '6m', '1y'} or integer
        default = '1m'
        don't support delinquency
        
        - '1m' 1 month
        - '3m' 3 months
        - '6m' 6 months
        - '1y' 1 year
        
    Returns
    -------
    res: dataframe
        columns: lender_id, aggregated value
    '''
    res = status_data[['lender_id', 'amount', 'submission_date', 'submission_month', \
                       'closing_date', 'closing_month', 'funded', 'loan_subtype']].sort_values('submission_date')
    
    
    loan_type_dict = {'fixflip': 'Fix and Flip (1-4)', \
                      'groudup': 'Groundup (1-4)', \
                      'smallbalance': 'Small Balance MF / Mixed Use (5+)', \
                      'rental': 'Rental (1-4)'}
    # loan type
    if loan_type != None:
        res = res[res.loan_subtype == loan_type_dict[loan_type]]
        
    # time filtering
    time_dict = {'1m': time1M, '3m': time3M, '6m': time6M, '1y': time1Y}
    
    if not delinquency and not momentum:

        # submitted or funded
        if funded and not submitted:
            res = res[res.funded == True]
            res = res[res['closing_date'] >= time_dict[time_period]]
        elif submitted and not funded:
            res = res[res['submission_date'] >= time_dict[time_period]]
        else:
            return
            
        # aggregate
        if amount and not times:
            return res.groupby("lender_id").amount.sum()
        
        if times and not amount:
            res = res[res['amount'] > 1000]
            return res.groupby("lender_id").amount.count()
        
    elif momentum:
        
        if type(time_period) != int:
            print("ERROR time_period parameter!")
            return None
        
        # last month submitted loan = 0: momentum = -1
        # lack of the most recent three months data: momentum = None
        # momentum value 
        momentum_values = []
        lender_list = list(res.lender_id.unique())
        
        for each_lender in lender_list:
            
            lender_df = res[res['lender_id'] == each_lender]
            lender_df = lender_df.sort_values(by = "submission_date")
            
            last_month = dt.datetime(time1M.year, time1M.month, 1).date()
            if lender_df['submission_date'].max() < last_month:
                momentum_values.append(-1)
                continue
            else:
                lender_df = lender_df.groupby("submission_month").amount.sum()
                lender_df = lender_df.cumsum()

                month_tmp = pd.DataFrame({"submission_month": [last_month - \
                                           relativedelta(months = x) for x in range(time_period)]})
                merged_df = pd.merge(month_tmp, lender_df, on = "submission_month", how = "inner")
                           
                if len(merged_df) < 3:
                    momentum_values.append(None)
                    continue
                else:
                    slope = (merged_df.amount.iloc[0] - \
                             merged_df.amount.iloc[-1])/(time_period*merged_df.amount.mean())
                    momentum_values.append(slope)
        return pd.DataFrame({"lender_id": lender_list, \
                             "momentum": momentum_values})

## Page layouts
# page 4 lender search
layout = html.Div([
            html.Div([
                Header(),
                html.Br([]),
            # dropdown: loan type; submitted or funded; transactions or amount; 1M, 3M, 6M, 1Y
            # dropdown 1
            html.Div([
                dcc.Dropdown(
                    id = 'loan_type',
                    options = [
                        {'label': 'All', 'value': 'None'},
                        {'label': 'Fix and Flip (1-4)', 'value': 'fixflip'},
                        {'label': 'Groundup (1-4)', 'value': 'groudup'},
                        {'label': 'Small Balance MF / Mixed Use (5+)', 'value': 'smallbalance'},
                        {'label': 'Rental (1-4)', 'value': 'rental'},
                    ],
                    value = 'None',
                    style = {"width": "200px", 'display': 'inline-block'}
                ),
                # dropdown 2
                dcc.Dropdown(
                    id = 'submitted',
                    options=[
                        {'label': 'Submitted', 'value': 'True'},
                        {'label': 'Funded', 'value': 'False'}
                    ],
                    value = 'True',
                    style = {"width": "160px", 'display': 'inline-block'}
                ),
                # dropdown 3
                dcc.Dropdown(
                    id = 'amount',
                    options=[
                        {'label': 'Transactions', 'value': 'False'},
                        {'label': 'Amount', 'value': 'True'}
                    ],
                    value = 'True',
                    style = {"width": "160px", 'display': 'inline-block'}
                ),
                # dropdown 4
                dcc.Dropdown(
                    id = 'time_period',
                    options=[
                        {'label': '1 month', 'value': '1m'},
                        {'label': '3 month', 'value': '3m'},
                        {'label': '6 month', 'value': '6m'},
                        {'label': '1 year', 'value': '1y'},
                    ],
                    value = '1m',
                    style = {"width": "160px", 'display': 'inline-block'}
                )
            ]),
           
            # table
            html.Div([
                dcc.Graph(id = 'leaderboard_tb', config = {'displayModeBar': False})
            ], style = {'margin-right': "40px", 'margin-left': "12px"})
            ], className="subpage")
        ], className="page")
        
@app.callback(
    output = Output('leaderboard_tb', 'figure'),
    inputs = [Input('loan_type', 'value'),
              Input('submitted', 'value'),
              Input('amount', 'value'),
              Input('time_period', 'value')])
def update_table(loan_type, submitted, amount, time_period):
    if loan_type == 'None':
        loan_type = None

    df = leaderboard_data(loan_type = loan_type, submitted = eval(submitted), funded = not eval(submitted), \
                          amount = eval(amount), times = not eval(amount), time_period = time_period)
    df = pd.merge(lender_name, df, on = "lender_id")
    df.columns = ['lender_name', 'alias', 'lender_id', 'value']
    df = df.sort_values(by = "value", ascending = False)

    return {
        "data": [go.Table(
                    header = dict(values = df.columns,
                                  fill_color = 'lightskyblue',
                                  align = 'left',
                                  font = {"size": 13}),
                    cells = dict(values = [df.iloc[:,0], df.iloc[:,1], df.iloc[:,2], df.iloc[:,3]],
                                 fill_color='lightcyan',
                                 align = 'left'
                                 ),
                    columnwidth = [200, 80, 50, 100],
                )],
        "layout": go.Layout(
            # width = '50%',
            height = 650,
            margin = {
                "r": 5,
                "t": 10,
                "b": 5,
                "l": 5
                }
        )
    }
