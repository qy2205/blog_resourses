# coding: utf-8
import os
import time
import pandas as pd

import dash
import dash_table
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output
import plotly.graph_objs as go
from app import app

import sys
sys.path.append(os.getcwd()+"/apps")
from backend import *
from template import Header

import warnings
warnings.filterwarnings("ignore")

# get data
diff_df = pd.read_excel("db/comments.xlsx")

PAGE_SIZE = 20
## Page layouts
# page 4 lender search
layout = html.Div([
            html.Div([
                Header(),
                html.Br([]),
            
            # table
            html.Div([
                dcc.Interval(id='interval-component', interval=10*1000),
                dash_table.DataTable(
                    id='datatable-paging',
                    columns = [{"name": i, "id": i} for i in diff_df.columns],
                    # data = diff_df.to_dict("rows"),
                    style_cell={
                        'minWidth': '0px', 
                        'maxWidth': '120px',
                        'textAlign': 'left'
                    },
                    style_header={
                        'backgroundColor': 'rgb(230, 230, 230)',
                        'fontWeight': 'bold'
                    },
                    page_current = 0,
                    page_size = PAGE_SIZE,
                    page_action = 'custom'
                )
            ], style = {'margin-right': "40px", 'margin-left': "12px"})

            ], className="subpage")
        ], className="page")

@app.callback(
    output = Output('datatable-paging', 'data'),
    inputs = [Input('datatable-paging', "page_current"),
              Input('datatable-paging', "page_size"),
              Input('interval-component', 'n_intervals')])
def update_table(page_current, page_size, n_intervals):
    df = pd.read_excel('db/comments.xlsx')
    df = df.sort_values(by = "update_time", ascending = False)
    df["update_time"] = df["update_time"].map(lambda x: str(x)[:16])
    df[' index'] = range(1, len(df) + 1)
    return df.iloc[
        page_current*page_size:(page_current+ 1)*page_size
    ].to_dict("records")
