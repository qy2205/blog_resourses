# coding: utf-8
import os
import pandas as pd
from openpyxl import load_workbook
import datetime as dt
import psycopg2

#import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output, State
import plotly.graph_objs as go
from app import app

import sys
sys.path.append(os.getcwd()+"/apps")
sys.path.append('../')
from backend import status_data, lender_delinquency
from backend import lender_series, moving_average, moving_quantile
from template import Header

# connect to the database
conn = 0
host = 'anqadb.citbtxda2m9k.us-east-1.rds.amazonaws.com'
try:
    conn = psycopg2.connect(host = host, database = 'roc_portal_db', \
                            user = 'portal_ro', password = 't0tallywelc0me')
except psycopg2.DatabaseError:
    print('failed to connect to database')

# ---------------------- lender name ---------------------- #
lender_query = '''
    select
        lender_id,
        participant,
        lender_name,
        email_address, 
        phone
    from
        lenders
'''

# get lender data
lender_name = pd.read_sql_query(sql = lender_query, con = conn)
lender_name = lender_name.dropna()
lender_name.columns = ["value", "label", "lender_name", "email", "phone"]
lender_name["value"] = lender_name["value"].map(str)
lender_id_list = list(lender_name["value"])
lender_name_dict = lender_name[["label", "value"]].to_dict("records")

lender_name.index = range(len(lender_name))
lender_alias_dict = {}
for i in range(len(lender_name)):
    lender_alias_dict[lender_name['value'][i]] = lender_name['lender_name'][i]
    
# ---------------------- functions ---------------------- #
def append_df_to_excel(filename, df, sheet_name='Sheet1', startrow=None,
                       truncate_sheet=False, 
                       **to_excel_kwargs):
    """
    Append a DataFrame [df] to existing Excel file [filename]
    into [sheet_name] Sheet.
    If [filename] doesn't exist, then this function will create it.

    Parameters:
      filename : File path or existing ExcelWriter
                 (Example: '/path/to/file.xlsx')
      df : dataframe to save to workbook
      sheet_name : Name of sheet which will contain DataFrame.
                   (default: 'Sheet1')
      startrow : upper left cell row to dump data frame.
                 Per default (startrow=None) calculate the last row
                 in the existing DF and write to the next row...
      truncate_sheet : truncate (remove and recreate) [sheet_name]
                       before writing DataFrame to Excel file
      to_excel_kwargs : arguments which will be passed to `DataFrame.to_excel()`
                        [can be dictionary]

    Returns: None
    """
    # ignore [engine] parameter if it was passed
    if 'engine' in to_excel_kwargs:
        to_excel_kwargs.pop('engine')
    writer = pd.ExcelWriter(filename, engine='openpyxl')

    # Python 2.x: define [FileNotFoundError] exception if it doesn't exist 
    try:
        FileNotFoundError
    except NameError:
        FileNotFoundError = IOError

    try:
        # try to open an existing workbook
        writer.book = load_workbook(filename)
        # get the last row in the existing Excel sheet
        # if it was not specified explicitly
        if startrow is None and sheet_name in writer.book.sheetnames:
            startrow = writer.book[sheet_name].max_row
        # truncate sheet
        if truncate_sheet and sheet_name in writer.book.sheetnames:
            # index of [sheet_name] sheet
            idx = writer.book.sheetnames.index(sheet_name)
            # remove [sheet_name]
            writer.book.remove(writer.book.worksheets[idx])
            # create an empty sheet [sheet_name] using old index
            writer.book.create_sheet(sheet_name, idx)
        # copy existing sheets
        writer.sheets = {ws.title:ws for ws in writer.book.worksheets}
    except FileNotFoundError:
        # file does not exist yet, we will create it
        pass

    if startrow is None:
        startrow = 0

    # write out the new sheet
    df.to_excel(writer, sheet_name, startrow=startrow, **to_excel_kwargs, \
                header = False, index = False)
    # save the workbook
    writer.save()

# -------------------------- Page layouts -------------------------- #
# page 4 lender search
layout = html.Div([
            html.Div([

                Header(),
                html.Br([]),
                
                # seperate SPL search tool
                html.Div([
                    # html.Strong("SPLs name:", style = {'padding-right': "16px", 'margin-bottom': "50px"}),
                    dcc.Dropdown(id='lender_id', value = "1", style = {"width": "550px", 'margin-left': "5px", 'display': 'inline-block'},\
                                options = lender_name_dict)
                ]),

                html.Div([
                    html.Div([
                        # row 1
                        html.Div([
                            html.Strong("Window:", style = {'padding-right': "34px", 'margin-left': "12px"}),
                            dcc.Input(id='wd', type='text', value = "2", style = {"width": "200px"}),
                        ]),

                        # row 2
                        # change quantile
                        html.Div([
                            html.Div([
                                html.Strong("Quantile value:", style = {'display': 'inline-block', \
                                                                        'margin-left': "12px"}),
                                html.Div([
                                    dcc.Slider(
                                        id='quantile_value',
                                        marks={
                                            0: '0%',
                                            0.25: '25%',
                                            0.5: '50%',
                                            0.75: '75%',
                                            1: '100%'
                                        },
                                        min = 0,
                                        max = 1,
                                        value = 0.5,
                                        step = 0.01,
                                        updatemode='drag')
                                ], style = {'width': '170px', 'display': 'inline-block', \
                                            'margin-left': "12px"})
                            ], style = {'margin-bottom': "40px"}),

                            # row 3 submitted or funded
                            html.Div([
                                dcc.RadioItems(
                                        options=[
                                            {'label': 'Submitted', 'value': 'submit'},
                                            {'label': 'Funded', 'value': 'funded'}
                                        ],
                                        value='submit',
                                        labelStyle = {'display': 'inline-block', 'margin-right': "20px"},
                                        style = {'margin-left': "10px"},
                                        id = "monitor_submit_fund"
                                    )
                            ]),
                        ])
                    ], style = {'display': 'inline-block'}),

                    # right
                    html.Div([
                        dcc.Graph(id = 'lender_info',
                                  config = {'displayModeBar': False})
                    ], style = {'display': 'inline-block', 'margin-left': "12px"}),
                ], style = {'display': 'flex', 'margin-bottom': "20px"}),

                # row 4 submitted or funded
                html.Div([
                    dcc.Checklist(
                            options=[
                                {'label': 'Fix&Flip (1-4)', 'value': 'Fix and Flip (1-4)'},
                                {'label': 'Rental (1-4)', 'value': 'Rental (1-4)'},
                                {'label': 'Small Balance MF', 'value': 'Small Balance MF / Mixed Use (5+)'},
                                {'label': 'Groundup (1-4)', 'value': 'Groundup (1-4)'}
                            ],
                            value=['Fix and Flip (1-4)', 'Rental (1-4)', 'Small Balance MF / Mixed Use (5+)', \
                                   'Groundup (1-4)'],
                            labelStyle = {'display': 'inline-block', 'margin-right': "20px"},
                            style = {'margin-left': "10px"},
                            id = "monitor_loan_subtype"
                        )
                ]),

                # row 5 comments
                html.Div([
                    html.Strong("Comments:", style = {'padding-right': "10px"}),
                    dcc.Input(id = 'comment', type = 'text', value = '', style = {'width': '300px'}),
                    html.Button(id = 'submit_comment', n_clicks = 0, children = 'Comments', \
                                style = {'margin-left': "20px", 'margin-right': "10px"}),
                    html.Div(id = 'output_state', style = {'display': 'inline-block'})
                ], style = {'margin-left': "12px", 'margin-bottom': "15px"}),

                # row 6 Graph
                html.Div([
                    dcc.Graph(id = 'monitor')
                ], style = {'margin-left': "12px", 'margin-bottom': "5px"}),

            ], className="subpage")
        ], className="page")

# backend
@app.callback(
    Output('monitor', 'figure'),
    [Input('lender_id', 'value'),
     Input('quantile_value', "value"),
     Input('wd', 'value'),
     Input('monitor_submit_fund', 'value'),
     Input('monitor_loan_subtype', 'value')]
)
def display(lender_id, quantile_value, wd, monitor_submit_fund, monitor_loan_subtype):
    
    if lender_id not in lender_id_list:
        lender_id = "1"
    lender_id = int(lender_id)
    
    if monitor_loan_subtype != []:
        loan_subtype_data = status_data[status_data["loan_subtype"].isin(monitor_loan_subtype)]
    else:
        loan_subtype_data = status_data
    # get series
    if monitor_submit_fund == "funded":
        activity = lender_series(loan_subtype_data, lender_id, status = "funded")
    elif monitor_submit_fund == "submit":
        activity = lender_series(loan_subtype_data, lender_id)
    ma = moving_average(activity, window = int(wd))
    quant = moving_quantile(activity, window = int(wd), quantile = float(quantile_value))

    # graph
    x = activity.index
    traces = []

    # Bar plot
    trace = go.Bar(
        x = x,
        y = activity,
        name = "loan_amount",
    )
    traces.append(trace)

    for ss, name in zip([ma, quant], ["MA", "Quantile"]):
        trace = go.Scatter(
            x = x,
            y = ss,
            name = name,
        )
        traces.append(trace)

    # lender name
    try:
        each_name = lender_name[lender_name["value"] == str(lender_id)]["label"].values[0]
    except:
        print("wrong lender name")
        each_name = ""
    fig = {"data": traces,
           "layout": go.Layout(
                autosize = False,
                font = {
                    "family": "Raleway",
                    "size": 10
                },
                height = 400,
                hovermode = "closest",
                legend = {
                    "x": -0.0228945952895,
                    "y": -0.189563896463,
                    "orientation": "h",
                    "yanchor": "top"
                },
                margin = {
                    "r": 0,
                    "t": 30,
                    "b": 10,
                    "l": 35
                    },
                showlegend = True,
                title = "{0}".format(each_name),
                width = 600,
                yaxis = {
                    "autorange": True,
                    "range": [0, 22.9789473684],
                    "showgrid": False,
                    "showline": False,
                    "title": "",
                    "type": "linear",
                    "zeroline": False
                })}
    return fig

@app.callback(
    Output('lender_info', 'figure'),
    [Input('lender_id', 'value')]
)
def get_info_table(lender_id):
    # contact info
    df = lender_name[lender_name['value'] == lender_id]
    if len(df) != 0:
        alias = df["lender_name"].values[0]
        email = df["email"].values[0]
        phone = df["phone"].values[0]
    else:
        alias = "NA"
        email = "NA"
        phone = "NA"
    # delinquency info
    delinquency_df = lender_delinquency(int(lender_id))
    delinquency_df = delinquency_df.drop_duplicates(["loan_id", "lender_id"])
    if len(delinquency_df) != 0:
        total_amount = delinquency_df.loan_amount.sum()
        mba60_rate = delinquency_df[delinquency_df["mba_delinquencies"] == "MBA 60+"].loan_amount.sum()/total_amount
        mba60_rate = str(round(mba60_rate*100, 2)) + "%"
        mba30_rate = delinquency_df[delinquency_df["mba_delinquencies"] == "MBA 30"].loan_amount.sum()/total_amount
        mba30_rate = str(round(mba30_rate*100, 2)) + "%"
    else:
        mba60_rate = "NA"
        mba30_rate = "NA"
    return {
        "data": [go.Table(
                    columnwidth = [60, 100],
                    header = dict(values = [alias, "Information"],
                                  line_color = 'lightskyblue',
                                  fill_color = 'lightskyblue',
                                  align = 'left',
                                  font = {"size": 13}),
                    cells = dict(values = [["Email", "Phone", "MBA60+", "MBA30+"], 
                                           [email, phone, mba60_rate, mba30_rate]],
                                 line_color='lightcyan',
                                 fill_color='lightcyan',
                                 align = 'left'
                                 )
                )],
        "layout": go.Layout(
            width = 300,
            height = 150,
            margin = {
                "r": 5,
                "t": 5,
                "b": 5,
                "l": 30
                }
        )
    }

@app.callback(Output('output_state', 'children'),
    [Input('submit_comment', 'n_clicks')],
    [State('comment', 'value'),
     State('lender_id', 'value')])
def comment(n_clicks, input1, input2):
    try:
        each_name = lender_alias_dict[input2]
        df = pd.DataFrame({"lender_id": [input2], \
                        "lender_name": [each_name], \
                        "comments": [input1], \
                        "update_time": [dt.datetime.now()]})
        if input1 != "" and input1 != None:
            append_df_to_excel("db/comments.xlsx", df)
            return "SUCCESS UPDATE"
    except:
        print("ERROR Comments")
    
