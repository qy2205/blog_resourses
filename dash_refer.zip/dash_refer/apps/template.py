# coding: utf-8
import dash_html_components as html
import dash_core_components as dcc
from app import app
import base64

logo_path = 'roc_logo.png'
encoded_logo = base64.b64encode(open(logo_path, 'rb').read()).decode('ascii')

def Header():
    return html.Div([
        get_logo(),
        html.Br([]),
        get_menu()
    ])

def get_logo():
    logo = html.Div([
        html.Div([
            # html.Img(src=app.get_asset_url(logo_path), height='60px')
            html.Img(src='data:image/png;base64,{}'.format(encoded_logo), height='80px')
        ], className="ten columns padded"),
        html.Div([
            dcc.Link('Full View   ', href='/dash-financial-report/full-view')
        ], className="two columns page-view no-print")
    ], className="row gs-header")
    return logo


def get_menu():
    menu = html.Div([
        # dcc.Link('OVERVIEW   ', href = "/apps/overview", className = "tab first"),
        dcc.Link('MONITOR   ', href = "/apps/monitor", className = "tab first"),
        dcc.Link('RANK   ', href = "/apps/rank", className = "tab"),
        dcc.Link('SCORING   ', href = "/apps/scoring", className = "tab"),
        dcc.Link('LEADERBOARD   ', href = "/apps/leaderboard", className = "tab"),
        dcc.Link('GENERAL MONTH   ', href = "/apps/general_month", className = "tab"),
        dcc.Link('COMMENTS   ', href = "/apps/comment", className = "tab")
    ], className="row ")
    return menu