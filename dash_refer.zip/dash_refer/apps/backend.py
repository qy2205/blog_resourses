import pandas as pd
import numpy as np
import re

import datetime as dt
from dateutil.relativedelta import relativedelta

#import statsmodels.api as sm
#from statsmodels.stats.outliers_influence import summary_table

import psycopg2
# connect to the database
conn = 0
host = 'anqadb.citbtxda2m9k.us-east-1.rds.amazonaws.com'
try:
    conn = psycopg2.connect(host = host, database = 'roc_portal_db', \
                            user = 'portal_ro', password = 't0tallywelc0me')
except psycopg2.DatabaseError:
    print('failed to connect to database')

# ---------------------------- global constant ---------------------------- #
# request data
status_query = '''
    select
        loans.loan_id,
        loans.lender_id,
        loans.amount,
        loans.submission_date,
        loans.closing_date,
        loans.payoff_date,
        loan_statuses.name as status,
        loan_statuses.loan_status_id as status_id,
        loans.loan_subtype
    from
        loans, loan_statuses
    where
        loan_statuses.loan_status_id = loans.loan_status_id
        and loan_type = 'Residential'
        and amount != 0
    order by loan_id
'''

# ---------------------- lender name ---------------------- #
lender_query = '''
    select
        participant,
        lender_name,
        lender_id
    from
        lenders
'''

# get lender data
lender_name = pd.read_sql_query(sql = lender_query, con = conn)
lender_name = lender_name.dropna()

# labeling
status_data = pd.read_sql_query(sql = status_query, con = conn)
status_data["funded"] = status_data["status_id"].map(lambda x: True if x in (3, 4, 8) else False)
status_data["paid_off"] = status_data["status_id"].map(lambda x: True if (x == 4) or (x == 8) else False)
status_data = status_data.dropna(subset = ["lender_id"])
status_data["lender_id"] = status_data["lender_id"].map(lambda x: int(x))
status_data["submission_month"] = status_data["submission_date"].map(lambda x: \
                                  dt.datetime.strptime(str(x)[:7], '%Y-%m').date())
status_data["closing_date"] = status_data["closing_date"].fillna(dt.datetime.now().date())
status_data["closing_month"] = status_data["closing_date"].map(lambda x: \
                                  dt.datetime.strptime(str(x)[:7], '%Y-%m').date())

# time template
day_tmp = pd.DataFrame(index = list(range(1, 32)))
timenow = dt.datetime.now().date()
year_month_now = str(timenow)[:7]
monthnow = dt.datetime.now().date().month
monthlast = monthnow - 1 if monthnow != 1 else 12
yearnow = dt.datetime.now().date().year
daynow = dt.datetime.now().date().day
end_date = dt.datetime.strptime('{0}-{1}'.format(yearnow, monthnow), "%Y-%m")

# current month bug: change year
curmonth = "{0}-{1}".format(yearnow, str(monthnow).zfill(2))
if monthlast == 12:
    lastmonth = "{0}-{1}".format(yearnow - 1, str(monthlast).zfill(2))
else:
    lastmonth = "{0}-{1}".format(yearnow, str(monthlast).zfill(2))

# ---------------------------- general month ---------------------------- #
# format data
def format_date(df, month_list, day_tmp):
    res = []
    for each_month in month_list:
        tmp = df[df["year-month"] == each_month].sort_values(by = "day", \
            ascending = True).groupby("day").amount.sum()
        res.append(tmp)
    res.append(day_tmp)
    return pd.concat(res, axis = 1)

# get filtered table
def get_date(lender_id, status_data = status_data, funded = False, paid_off = False, \
             time_period = 6):
    # lender id filtering
    status_data = status_data[status_data["lender_id"] == lender_id]

    # time filtering
    start_date = timenow + relativedelta(months=-time_period)
    start_year = start_date.year
    start_month = start_date.month
    start_date = dt.datetime.strptime('{0}-{1}-01'.format(start_year, \
                                       start_month), "%Y-%m-%d")
    
    # funded or paid_off
    if funded:
        filtered_data = status_data[status_data["closing_date"] >= start_date.date()]
        filtered_data = filtered_data[filtered_data["funded"] == True]
    elif paid_off:
        filtered_data = status_data[status_data["closing_date"] >= start_date.date()]
        filtered_data = filtered_data[filtered_data["paid_off"] == True]
    else:
        filtered_data = status_data[status_data["submission_date"] >= start_date.date()]
    
    # processing data
    if funded or paid_off:
        groupbydt = pd.DataFrame(filtered_data.groupby("submission_date").amount.sum())
    else:
        groupbydt = pd.DataFrame(filtered_data.groupby("submission_date").amount.sum())
        
    groupbydt["day"] = groupbydt.index.map(lambda x: x.day)
    groupbydt["year-month"] = groupbydt.index.map(lambda x: str(x)[:7])
    
    # get month list
    month_list = []
    for i in range(time_period):
        month_list.append(str(start_date + relativedelta(months=i))[:7])
    month_list.append(year_month_now)
    
    # format data
    res = format_date(groupbydt, month_list, day_tmp)
    res.columns = month_list
    res = res.fillna(0)
    res = res.cumsum()

    # current month
    res[curmonth].iloc[daynow:] = np.nan
    return res

def conf_inv_mean(df, curmonth, z = 1.96):
    X = df.drop([curmonth], axis = 1)
    mean_series = X.T.mean()
    # conf int for mean
    std_series = X.T.std()/X.shape[1]
    low_int = mean_series - z*std_series
    high_int = mean_series + z*std_series
    return mean_series, low_int, high_int

# def conf_inv_median(df, curmonth, z = 1.96):
#     X = df.drop([curmonth], axis = 1)
#     med_series = X.T.median()
#     # conf int for median
#     low_int = []
#     high_int = []
#     for i in range(len(X)):
#         data = sorted(X.iloc[i].values)
#         low_pos = int(len(data)/2 - z*np.sqrt(len(data))/2)
#         high_pos = int(1 + len(data)/2 + z*np.sqrt(len(data))/2)
#         low_int.append(data[low_pos])
#         high_int.append(data[high_pos])
#     return med_series, low_int, high_int

def conf_inv_quantile(df, curmonth, quantile):
    X = df.drop([curmonth], axis = 1)
    quantile_series = X.T.quantile(quantile)
    return quantile_series

# ---------------------------- monitor ---------------------------- #
# input status data
def lender_series(df, lender_id, status = "submitted"):
    lender_df = df[df["lender_id"] == lender_id]
    lender_df = lender_df.drop_duplicates(subset = "loan_id")
    if status == "funded":
        lender_df = lender_df[lender_df["funded"] == True]
        lender_df["month"] = lender_df["closing_date"].map(lambda x: str(x)[:7])
    else:
        lender_df["month"] = lender_df["submission_date"].map(lambda x: str(x)[:7])
    monthly_dt = lender_df.groupby("month").amount.sum()
    return monthly_dt

# input series
def moving_average(ss, window):
    return ss.rolling(window).mean()

# input series
def moving_quantile(ss, window, quantile):
    return ss.rolling(window).quantile(quantile)

# --------------------- general month statistics --------------------- #
# input status data
def genral_month_stat(df, lender_id, status = "submitted"):
    lender_df = df[df["lender_id"] == lender_id]
    lender_df = lender_df.drop_duplicates(subset = "loan_id")
    if status == "funded":
        lender_df = lender_df[lender_df["funded"] == True]
        lender_df["month"] = lender_df["closing_date"].map(lambda x: str(x)[:7])
    else:
        lender_df["month"] = lender_df["submission_date"].map(lambda x: str(x)[:7])
    # get month
    monthly_dt = lender_df.groupby("month").amount.sum()
    return monthly_dt

# ---------------------- Delinquency Statistics ---------------------- #
# def mba60_map(x):
#     if x != x or x == None:
#         return "0"
#     for each in [r"60", r"90", r"X", r"F"]:
#         if re.findall(each, x) != []:
#             return "MBA60+"
#     return "other"

# def mba30_map(x):
#     if x != x or x == None:
#         return "0"
#     for each in [r"30", r"60", r"90", r"X", r"F"]:
#         if re.findall(each, x) != []:
#             return "MBA30+"
#     return "other"

sql_delinquency = '''
        select
            v.loan_id,
            v.loan_amount,
            l.lender_id,
            case
                when v.next_due_date <= to_date(concat(to_char(current_date - (interval '1 month') * 2, 'YYYY-MM'), '-01'), 'YYYY-MM-DD') then 'MBA 60+'
                when v.next_due_date <= to_date(concat(to_char(current_date - (interval '1 month') * 1, 'YYYY-MM'), '-01'), 'YYYY-MM-DD') then 'MBA 30'
                else 'Current'
            end as mba_delinquencies
        from v_loan_tape_data_w_lender_trade_id_all v
        join lenders l on
            l.lender_name = v.lender
        where
            v.loan_type = 'Residential'
            and v.loan_status = 3
'''

delinquency = pd.read_sql_query(sql = sql_delinquency, con = conn)

def lender_delinquency(lender_id):
    df = delinquency[delinquency["lender_id"] == lender_id]
    return df
