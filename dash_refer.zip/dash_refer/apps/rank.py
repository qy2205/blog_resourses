# coding: utf-8
import os

import math
import pandas as pd
import numpy as np

import dash_table
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output
from app import app

import sys
sys.path.append(os.getcwd()+"/apps")
from backend import *
from template import Header

import warnings
warnings.filterwarnings("ignore")

# ---------------------- functions ---------------------- #
def get_lender_name(x, col = "participant"):
    try:
        return lender_name[lender_name["lender_id"] == x][col].values[0]
    except:
        return "NO RECORDES"

millnames = ['',' Thousand',' Million',' Billion',' Trillion']
def millify(n):
    if n == np.inf:
        return "not active"
    n = float(n)
    millidx = max(0,min(len(millnames)-1,
                        int(math.floor(0 if n == 0 else math.log10(abs(n))/3))))
    return '{:.0f}{}'.format(n / 10**(3 * millidx), millnames[millidx])

# ranking algorithm
# 1. Current month loan amount, last month: based on Gap
# 2. Current month loan amount, None: not included 
# 3. None, last month: Top
# 4. None, None: not included

diff_res = []
diff_ratio = []
lender_id_ls = lender_name.lender_id.map(int).unique()
for each_lender in lender_id_ls:
    activity = lender_series(status_data, each_lender)
    activity = activity[activity >= 1000]
    # ma3 = moving_average(activity, window = int(3))
    # if we don't have enough data
    if len(activity) <= 1:
        diff_res.append(0)
        diff_ratio.append(0)
        
    # if current month ==/!= None, last month == None
    elif sum(activity.index == lastmonth) == 0:
        diff_res.append(0)
        diff_ratio.append(0)
        
    # if current month == None, last month != None
    elif sum(activity.index == lastmonth) != 0 and \
         sum(activity.index == curmonth) == 0:
        diff_res.append(np.inf)
        diff_ratio.append(1)
        
    # if current month != None, last month != None
    elif sum(activity.index == lastmonth) != 0 and \
         sum(activity.index == curmonth) != 0:
        lastamount = activity[lastmonth]
        curamount = activity[curmonth]
        diff_res.append(lastamount - curamount)
        diff_ratio.append(round((lastamount - curamount)/lastamount, 2))

# build dataframe
diff_df = pd.DataFrame({"lender_id": lender_id_ls, "diff_res": diff_res})
diff_df["lender_name"] = diff_df["lender_id"].map(get_lender_name)
diff_df["alias"] = diff_df["lender_id"].map(lambda x: get_lender_name(x, col = "lender_name"))
diff_df["chg_%"] = diff_ratio

# filtering and ranking
diff_df = diff_df.sort_values(by = ["chg_%", "diff_res"], ascending = False)
diff_df = diff_df[diff_df["diff_res"] > 0]
diff_df["diff_show"] = diff_df["diff_res"].map(millify)
diff_df[' index'] = range(1, len(diff_df) + 1)

# change name and order
diff_df.columns = ["Lender_id", "diff_res", "Name", "Alias", "Chg %", "Gap","Rank"]
diff_df = diff_df[["Rank", "Lender_id", "Name", "Alias", "Gap", "Chg %", "diff_res"]]
diff_df.to_excel('db/rank.xlsx', index = False)

## Page layouts
# page 4 lender search
layout = html.Div([
            html.Div([
                Header(),
                html.Br([]),
            # table
            html.Div([
                dcc.Interval(id='interval-component', interval=10*1000),
                dash_table.DataTable(
                    id = 'rank_table',
                    columns = [{"name": i, "id": i} for i in diff_df.columns[:-1]],
                    # data = diff_df.to_dict("rows"),
                    style_cell = {
                        'textAlign': 'left',
                        'minWidth': '0px', 
                        'maxWidth': '120px'
                    },
                    style_header = {
                        'backgroundColor': 'rgb(230, 230, 230)',
                        'fontWeight': 'bold'
                    },
                    page_current = 0,
                    page_size = 20,
                    page_action = 'custom',
                    sort_action = 'custom',
                    sort_mode = 'single',
                    sort_by=[]
                )
            ], style = {'margin-right': "40px", 'margin-left': "12px"})
            ], className="subpage")
        ], className="page")
        
@app.callback(
    output = Output('rank_table', 'data'),
    inputs = [Input('rank_table', "page_current"),
              Input('rank_table', "page_size"),
              Input('rank_table', 'sort_by'),
              Input('rank_table', 'n_intervals')])
def update_table(page_current, page_size, sort_by, n_intervals):
    if len(sort_by):
        # print(sort_by[0]['column_id'])
        if sort_by[0]['column_id'] == "Gap":
            sort_col = "diff_res"
        else:
            sort_col = sort_by[0]['column_id']
        df = diff_df.sort_values(
            by = sort_col,
            ascending=sort_by[0]['direction'] == 'asc',
            inplace=False
        )
    else:
        # No sort is applied
        df = diff_df
    df = df[["Rank", "Lender_id", "Name", "Alias", "Gap", "Chg %"]]
    return df.iloc[
        page_current*page_size:(page_current+ 1)*page_size
    ].to_dict("records")
