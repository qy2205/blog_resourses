# coding: utf-8
import os

import math
import pandas as pd
import numpy as np

import dash_table
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output
import plotly.graph_objs as go
from app import app

import sys
sys.path.append(os.getcwd()+"/apps")
from backend import *
from template import Header

import warnings
warnings.filterwarnings("ignore")

# ---------------------- global variable ---------------------- #
value_data = status_data[(status_data["status_id"].isin([3, 4, 8])) & (status_data["amount"] >= 1000)]
level1 = np.exp(12.408 - 2*0.734)
level2 = np.exp(12.408 - 0.734)
level3 = np.exp(12.408 + 0.734)
level4 = np.exp(12.408 + 2*0.734)

time_tmp = list(map(lambda x: str(x)[:10], pd.date_range(status_data.submission_date.min(), dt.datetime.now())))
time_tmp = pd.DataFrame({"date": time_tmp})

# ---------------------- lender name ---------------------- #
lender_query = '''
    select
        participant,
        lender_id
    from
        lenders
'''

# get lender data
lender_name = pd.read_sql_query(sql = lender_query, con = conn)
lender_name = lender_name.dropna()
lender_name.columns = ["label", "value"]
lender_name["value"] = lender_name["value"].map(str)
lender_id_list = list(lender_name["value"])
lender_name_dict = lender_name[["label", "value"]].to_dict("records")

# ---------------------- functions ---------------------- #
def score_map(x):
    if x < level1:
        return 0.8
    elif x >= level1 and x < level2:
        return 0.9
    elif x >= level2 and x < level3:
        return 1.0
    elif x >= level3 and x < level4:
        return 1.1
    else:
        return 1.2

def scorer(lender_id):
    # global: time_tmp, status_data(funded only)
    lender_df = value_data[value_data['lender_id'] == lender_id]
    if len(lender_df) == 0:
        return 0
    lender_df = lender_df.sort_values(by = "submission_date")
    lender_df["submission_date"] = lender_df["submission_date"].map(lambda x: str(x)[:10])
    lender_df['value'] = lender_df['amount'].map(score_map)
    res = lender_df.groupby("submission_date").value.sum().cumsum()
    return round(res.iloc[-1], 1)

def scorer_ts(lender_id):
    # global: time_tmp, status_data(funded only)
    lender_df = value_data[value_data['lender_id'] == lender_id]
    lender_df = lender_df.sort_values(by = "submission_date")
    lender_df["submission_date"] = lender_df["submission_date"].map(lambda x: str(x)[:10])
    lender_df['value'] = lender_df['amount'].map(score_map)
    res_df = lender_df.groupby("submission_date").value.sum().cumsum()
    res_df = pd.merge(time_tmp, pd.DataFrame({"date": res_df.index, "value": res_df.values}), \
                      on = "date", how = "outer").fillna(method = "ffill")
    res_df['date'] = pd.to_datetime(res_df['date'])
    return res_df

# customer score
scores = []
for lid in lender_name["value"]:
    scores.append(scorer(int(lid)))
score_df = pd.DataFrame({"lender": lender_name["label"], "score": scores})
score_df = score_df.sort_values(by = "score", ascending = False)

# ----------------------------------------------------

## Page layouts
# page 4 lender search
layout = html.Div([
            html.Div([
                Header(),
                html.Br([]),
                # SPL input
                html.Div([
                    dcc.Dropdown(id='lender_id', value = "None", style = {"width": "650px", 'margin-left': "5px", 'display': 'inline-block'},\
                                options = lender_name_dict, multi=True)
                ]),

                # Graph
                html.Div([
                    dcc.Graph(id = 'compare_plot', config = {'displayModeBar': True})
                ], style = {'margin-right': "40px", 'margin-left': "12px"}),

                html.Br([]),

                # Table
                html.Div([
                    dash_table.DataTable(
                        id = 'score_table',
                        columns=[{"name": i, "id": i} for i in score_df.columns],
                        page_current = 0,
                        page_size = 8,
                        page_action = 'custom',
                        style_cell = {
                            'textAlign': 'left'
                        },
                    )
                ], style = {'margin-right': "40px", 'margin-left': "12px"}),
            ], className="subpage")
        ], className="page")
        
@app.callback(
    output = Output('compare_plot', 'figure'),
    inputs = [Input('lender_id', 'value')])
def update_table(lender_id):
    if lender_id == 'None':
        res = scorer_ts(1)
        traces = [go.Scatter(
            x = res['date'],
            y = res['value'],
            name = lender_name[lender_name['value'] == '1']['label'].values[0]
        )]
    else:
        traces = []
        for each in lender_id:
            res = scorer_ts(int(each))
            trace = go.Scatter(
                x = res['date'],
                y = res['value'],
                name = lender_name[lender_name['value'] == each]['label'].values[0]
            )
            traces.append(trace)
    return {
        "data": traces,
        "layout": go.Layout(
            # width = '50%',
            height = 300,
            margin = {
                "r": 5,
                "t": 10,
                "b": 20,
                "l": 30
                }
        )
    }

@app.callback(
    output = Output('score_table', 'data'),
    inputs = [Input('score_table', "page_current"),
              Input('score_table', "page_size")])
def update_table(page_current, page_size):
    return score_df.iloc[
        page_current*page_size:(page_current+ 1)*page_size
    ].to_dict("records")