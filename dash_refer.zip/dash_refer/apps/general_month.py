# coding: utf-8
import os
import pandas as pd
import datetime as dt
import psycopg2

import dash
import dash_table
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output
import plotly.graph_objs as go
from app import app

import sys
sys.path.append(os.getcwd()+"/apps")
from backend import *
from template import Header

# connect to the database
conn = 0
host = 'anqadb.citbtxda2m9k.us-east-1.rds.amazonaws.com'
try:
    conn = psycopg2.connect(host = host, database = 'roc_portal_db', \
                            user = 'portal_ro', password = 't0tallywelc0me')
except psycopg2.DatabaseError:
    print('failed to connect to database')

# ---------------------- lender name ---------------------- #
lender_query = '''
    select
        participant,
        lender_id
    from
        lenders
'''

# get lender data
lender_name = pd.read_sql_query(sql = lender_query, con = conn)
lender_name = lender_name.dropna()
lender_name.columns = ["label", "value"]
lender_name["value"] = lender_name["value"].map(str)
lender_id_list = list(lender_name["value"])
lender_name_dict = lender_name[["label", "value"]].to_dict("records")

## Page layouts
# page 4 lender search
layout = html.Div([
            html.Div([
                Header(),
                html.Br([]),

                # row 1
                # html.Div([
                #     html.Strong("SPLs id:", style = {'padding-right': "40px", 'margin-left': "12px"}),
                #     dcc.Input(id='lender_id', type='text', value = "1", style = {"width": "400px"}),
                #     html.Button("Search id", 
                #     id = 'btn_1',
                #     n_clicks_timestamp = 0,
                #     style = {'margin-left': "20px", "width": "150px"}),
                # ]),

                # seperate SPL search tool
                html.Div([
                    # html.Strong("SPLs name:", style = {'padding-right': "16px", 'margin-bottom': "50px"}),
                    dcc.Dropdown(id='lender_id', value = "1", style = {"width": "550px", 'margin-left': "5px", 'display': 'inline-block'},\
                                options = lender_name_dict)
                ]),

                html.Br(),

                # row 3
                # Graph and bar
                html.Div([
                    html.Div([
                        html.Strong("Confidence interval:", style = {'display': 'inline-block', 'margin-left': "12px"}),
                        html.Div([
                            dcc.Slider(
                                id = 'z_value',
                                marks = {i: '{}'.format(i) for i in range(4)},
                                min = 0,
                                max = 3,
                                value = 1.645,
                                step = 0.1,
                                updatemode ='drag')
                        ], style = {'width': '400px', 'display': 'inline-block', 'margin-left': "20px"})
                    ]),
                    html.Br(),
                    html.Div([
                        html.Strong("Quantile value:", style = {'display': 'inline-block', 'margin-left': "12px"}),
                        html.Div([
                            dcc.Slider(
                                id='quantile_value',
                                marks={
                                    0: '0%',
                                    0.25: '25%',
                                    0.5: '50%',
                                    0.75: '75%',
                                    1: '100%'
                                },
                                min = 0,
                                max = 1,
                                value = 0.5,
                                step = 0.01,
                                updatemode='drag')
                        ], style = {'width': '400px', 'display': 'inline-block', 'margin-left': "55px"}),
                    ]),
                    html.Br(),
                    dcc.RadioItems(
                        options=[
                            {'label': 'Submitted', 'value': 'submit'},
                            {'label': 'Funded', 'value': 'funded'},
                            {'label': 'Paid off', 'value': 'paid off'}
                        ],
                        value='submit',
                        labelStyle = {'display': 'inline-block', 'margin-right': "20px"},
                        style = {'margin-left': "10px"},
                        id = "fund"
                    ),
                    html.Div([dcc.Graph(id = 'tracking_user')]),
                ])
            ], className="subpage")
        ], className="page")

# backend
@app.callback(
    Output('tracking_user', 'figure'),
    [Input('lender_id', 'value'),
     Input('z_value', "value"),
     Input('quantile_value', "value"),
     Input('fund', 'value')]
)
def display(lender_id, z_value, quantile_value, fund):
    # search based on lender id
    # if lender_id == "None":
    #     lender_id = 1
    # else:
    #     lender_id = int(lender_id)

    if lender_id not in lender_id_list:
        lender_id = "1"
    lender_id = int(lender_id)

    # funded, submitted or paid off
    if fund == "funded":
        plotdata = get_date(lender_id, status_data = status_data, \
            funded = True, paid_off = False, time_period = 6)
    elif fund == "submit":
        plotdata = get_date(lender_id, status_data = status_data, \
            funded = False, paid_off = False, time_period = 6)
    elif fund == "paid off":
        plotdata = get_date(lender_id, status_data = status_data, \
            funded = False, paid_off = True, time_period = 6)
            
    # confidence interval
    mean_series, low_int, high_int = conf_inv_mean(df = plotdata, \
        curmonth = curmonth, z = z_value)
    quantiles = conf_inv_quantile(df = plotdata, curmonth = curmonth, \
        quantile = quantile_value)

    # graph
    x = plotdata.index
    traces = []
    for each, name in zip(list(plotdata.T.values), plotdata.columns):
        if name == curmonth:
            trace = go.Scatter(
                x = x,
                y = each,
                name = name,
                line = dict(color = "#365062", width = 6)
            )
            traces.append(trace)
            break
        # normal line
        trace = go.Scatter(
            x = x,
            y = each,
            name = name,
            opacity = 0.4
        )
        traces.append(trace)
    
    # add average, median
    fill = ["none", 'none', 'tonexty', "none"]
    names = ["average", "lower", "upper", "quantile"]
    widths = [5, 1, 1, 5]
    for each, each_fill, each_name, each_width in zip([mean_series, low_int, \
        high_int, quantiles], fill, names, widths):
        trace = go.Scatter(
            x = x,
            y = each,
            name = each_name,
            fill = each_fill,
            line = dict(width = each_width)
        )
        traces.append(trace)

    # lender name
    try:
        each_name = lender_name[lender_name["value"] == str(lender_id)]["label"].values[0]
    except:
        print("wrong")
        each_name = ""
    fig = {"data": traces,
            "layout": go.Layout(
                autosize = False,
                font = {
                    "family": "Raleway",
                    "size": 10
                },
                height = 400,
                hovermode = "closest",
                legend = {
                    "x": -0.0228945952895,
                    "y": -0.189563896463,
                    "orientation": "h",
                    "yanchor": "top"
                },
                margin = {
                    "r": 0,
                    "t": 30,
                    "b": 10,
                    "l": 35
                    },
                showlegend = True,
                title = "{0}".format(each_name),
                width = 600,
                yaxis = {
                    "autorange": True,
                    "range": [0, 22.9789473684],
                    "showgrid": False,
                    "showline": False,
                    "title": "",
                    "type": "linear",
                    "zeroline": False
                })}
    return fig


